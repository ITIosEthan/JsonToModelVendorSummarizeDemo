//
//  ViewController.m
//  mantleText
//
//  Created by macOfEthan on 17/8/16.
//  Copyright © 2017年 macOfEthan. All rights reserved.
//

#define textUrl @"http://news-at.zhihu.com/api/4/news/latest"


#import "ViewController.h"
#import <AFNetworking/AFNetworking.h>

#import "MantleTextModel.h"
#import "YYModelTextModel.h"
#import "JsonModelTextModel.h"

@interface ViewController ()

@property (nonatomic, strong) MantleTextModel *mantleModel;
@property (nonatomic, strong) YYModelTextModel *yyModel;
@property (nonatomic, strong) JsonModelTextModel *jsonModel;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (IBAction)Mantle:(UIButton *)sender {
    
    [[AFHTTPSessionManager manager] GET:textUrl parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"responseObject = %@", responseObject);
        
        _mantleModel = [MTLJSONAdapter modelOfClass:[MantleTextModel class] fromJSONDictionary:responseObject error:nil];
        
        for (mantle_storiesModel *m in _mantleModel.stories) {
            
            NSLog(@"m = %@", m);
        }
        
        for (mantle_top_storiesModel *m in _mantleModel.top_stories) {
            
            NSLog(@"m = %@", m);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
    
}


- (IBAction)YYModel:(UIButton *)sender {
    
    [[AFHTTPSessionManager manager] GET:textUrl parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        _yyModel = [YYModelTextModel yy_modelWithJSON:responseObject];
        
        for (yy_storiesModel *m in _yyModel.stories) {
            
            NSLog(@"m = %@", m);
        }
        
        for (yy_top_storiesModel *m in _yyModel.top_stories) {
            
            NSLog(@"m = %@", m);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
}


- (IBAction)JsonModel:(UIButton *)sender {
    
    [[AFHTTPSessionManager manager] GET:textUrl parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        _jsonModel = [[JsonModelTextModel alloc] initWithDictionary:responseObject error:nil];
        
        for (json_storiesModel *m in _jsonModel.stories) {
            
            NSLog(@"m = %@", m);
        }
        
        for (json_top_storiesModel *m in _jsonModel.top_stories) {
            
            NSLog(@"m = %@", m);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
}



@end
