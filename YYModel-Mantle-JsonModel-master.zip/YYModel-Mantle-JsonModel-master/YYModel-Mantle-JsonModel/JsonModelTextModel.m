//
//  JsonModelTextModel.m
//  mantleText
//
//  Created by macOfEthan on 17/8/16.
//  Copyright © 2017年 macOfEthan. All rights reserved.
//

#import "JsonModelTextModel.h"

@implementation JsonModelTextModel

//这个方法是把所有的属性全部设置为可选值，这样就算后台传过来的值是空值，也没有关系
+ (BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end

@implementation json_storiesModel

+ (JSONKeyMapper *)keyMapper
{
    return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:@{@"myId":@"id"}];
}

@end

@implementation json_top_storiesModel

+ (JSONKeyMapper *)keyMapper
{
    return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:@{@"myId":@"id"}];
}

@end
