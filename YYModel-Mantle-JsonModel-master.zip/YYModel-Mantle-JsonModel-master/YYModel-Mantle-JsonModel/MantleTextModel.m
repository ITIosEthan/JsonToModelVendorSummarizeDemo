//
//  TextModel.m
//  mantleText
//
//  Created by macOfEthan on 17/8/16.
//  Copyright © 2017年 macOfEthan. All rights reserved.
//

#import "MantleTextModel.h"

@implementation MantleTextModel

- (NSString *)description
{
    return [NSString stringWithFormat:@"date = %@", self.date];
}

#pragma mark - MTLJSONSerializing
//key为model属性 value为JsonKeyPaths
+ (NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{@"date":@"date",
             @"stories":@"stories",
             @"top_stories":@"top_stories"};
}

//指定对应的数组容器
+ (NSValueTransformer *)JSONTransformerForKey:(NSString *)key
{
    if ([key isEqualToString:@"stories"]) {
        return [MTLJSONAdapter arrayTransformerWithModelClass:[mantle_storiesModel class]];
    }else if ([key isEqualToString:@"top_stories"]){
        return [MTLJSONAdapter arrayTransformerWithModelClass:[mantle_top_storiesModel class]];
    }
    return nil;
}

@end

@implementation mantle_storiesModel

- (NSString *)description
{
    return [NSString stringWithFormat:@"images[0] = %@, type = %ld, myId = %ld, ga_prefix = %@, title = %@", self.images[0], self.type, self.myId, self.ga_prefix, self.title];
}

+ (NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{@"myId":@"id",
             @"images":@"images",
             @"type":@"type",
             @"ga_prefix":@"ga_prefix",
             @"title":@"title"};
}

@end

@implementation mantle_top_storiesModel

- (NSString *)description
{
    return [NSString stringWithFormat:@"images = %@, type = %ld, myId = %ld, ga_prefix = %@, title = %@", self.image, self.type, self.myId, self.ga_prefix, self.title];
}


+ (NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{@"myId":@"id",
             @"image":@"image",
             @"type":@"type",
             @"ga_prefix":@"ga_prefix",
             @"title":@"title"};
}

@end
