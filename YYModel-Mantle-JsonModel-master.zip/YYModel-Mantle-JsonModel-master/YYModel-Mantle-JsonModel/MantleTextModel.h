//
//  TextModel.h
//  mantleText
//
//  Created by macOfEthan on 17/8/16.
//  Copyright © 2017年 macOfEthan. All rights reserved.
//

#import <Mantle/Mantle.h>
@class mantle_storiesModel;
@class mantle_top_storiesModel;

@interface MantleTextModel : MTLModel<MTLJSONSerializing>

@property (nonatomic, copy) NSString *date;
@property (nonatomic, strong) NSArray *stories;
@property (nonatomic, strong) NSArray *top_stories;

@end


@interface mantle_storiesModel : MTLModel<MTLJSONSerializing>

@property (nonatomic, strong) NSArray *images;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic, assign) NSInteger myId;
@property (nonatomic, copy) NSString *ga_prefix;
@property (nonatomic, copy) NSString *title;

@end


@interface mantle_top_storiesModel : MTLModel<MTLJSONSerializing>

@property (nonatomic, copy) NSString *image;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic, assign) NSInteger myId;
@property (nonatomic, copy) NSString *ga_prefix;
@property (nonatomic, copy) NSString *title;

@end

