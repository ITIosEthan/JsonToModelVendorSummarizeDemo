//
//  YYModelTextModel.m
//  mantleText
//
//  Created by macOfEthan on 17/8/16.
//  Copyright © 2017年 macOfEthan. All rights reserved.
//

#import "YYModelTextModel.h"

@implementation YYModelTextModel

+ (nullable NSDictionary<NSString *, id> *)modelCustomPropertyMapper
{
    return @{@"date":@"date",
             @"stories":@"stories",
             @"top_stories":@"top_stories"};
}

+ (nullable NSDictionary<NSString *, id> *)modelContainerPropertyGenericClass
{
    return @{@"stories":[yy_storiesModel class],
             @"top_stories":[yy_top_storiesModel class]};
}

@end

@implementation yy_storiesModel

- (NSString *)description
{
    return [NSString stringWithFormat:@"images[0] = %@, type = %ld, myId = %ld, ga_prefix = %@, title = %@", self.images[0], self.type, self.myId, self.ga_prefix, self.title];
}

+ (nullable NSDictionary<NSString *, id> *)modelCustomPropertyMapper
{
    return @{@"myId":@"id"};
}

@end


@implementation yy_top_storiesModel

- (NSString *)description
{
    return [NSString stringWithFormat:@"images = %@, type = %ld, myId = %ld, ga_prefix = %@, title = %@", self.image, self.type, self.myId, self.ga_prefix, self.title];
}

+ (nullable NSDictionary<NSString *, id> *)modelCustomPropertyMapper
{
    return @{@"myId":@"id"};
}

@end
