//
//  YYModelTextModel.h
//  mantleText
//
//  Created by macOfEthan on 17/8/16.
//  Copyright © 2017年 macOfEthan. All rights reserved.
//

//优点：最佳轻量

#import <Foundation/Foundation.h>
#import <YYModel/YYModel.h>
@class yy_storiesModel;
@class yy_top_storiesModel;

@interface YYModelTextModel : NSObject

@property (nonatomic, copy) NSString *date;
@property (nonatomic, strong) NSArray <yy_storiesModel *>*stories;
@property (nonatomic, strong) NSArray <yy_top_storiesModel *>*top_stories;

@end


@interface yy_storiesModel : NSObject

@property (nonatomic, strong) NSArray *images;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic, assign) NSInteger myId;
@property (nonatomic, copy) NSString *ga_prefix;
@property (nonatomic, copy) NSString *title;

@end


@interface yy_top_storiesModel : NSObject

@property (nonatomic, copy) NSString *image;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic, assign) NSInteger myId;
@property (nonatomic, copy) NSString *ga_prefix;
@property (nonatomic, copy) NSString *title;

@end
