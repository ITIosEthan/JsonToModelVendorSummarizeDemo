//
//  ViewController.h
//  YYModel-Mantle-JsonModel
//
//  Created by macOfEthan on 17/8/16.
//  Copyright © 2017年 macOfEthan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

