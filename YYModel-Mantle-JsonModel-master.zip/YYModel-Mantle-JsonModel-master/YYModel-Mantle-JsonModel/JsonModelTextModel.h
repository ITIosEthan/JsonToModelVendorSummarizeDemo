//
//  JsonModelTextModel.h
//  mantleText
//
//  Created by macOfEthan on 17/8/16.
//  Copyright © 2017年 macOfEthan. All rights reserved.
//

#import <JSONModel/JSONModel.h>

//优点：无需自己重写-(NSString *)description 

//声明两个协议 名字和子模型一致
@protocol json_storiesModel;
@protocol json_top_storiesModel;

@interface JsonModelTextModel : JSONModel

@property (nonatomic, copy) NSString *date;
@property (nonatomic, strong) NSArray <json_storiesModel>*stories;
@property (nonatomic, strong) NSArray <json_top_storiesModel>*top_stories;

@end


@interface json_storiesModel : JSONModel

@property (nonatomic, strong) NSArray *images;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic, assign) NSInteger myId;
@property (nonatomic, copy) NSString *ga_prefix;
@property (nonatomic, copy) NSString *title;

@end

@interface json_top_storiesModel : JSONModel

@property (nonatomic, copy) NSString *image;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic, assign) NSInteger myId;
@property (nonatomic, copy) NSString *ga_prefix;
@property (nonatomic, copy) NSString *title;

@end
