//
//  ViewController.swift
//  KissXmlText
//
//  Created by macOfEthan on 17/8/18.
//  Copyright © 2017年 macOfEthan. All rights reserved.
//

import UIKit
import XMLReader

class ViewController: UIViewController {

    let xmlPath:String? = Bundle.main.path(forResource: "text.xml", ofType: nil)
    var stu:Stu?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    @IBAction func kissXml(_ sender: Any) {
        
        do
        {
            let xmlString:String? = try String.init(contentsOfFile: xmlPath!)
            
            let doc: DDXMLDocument = try DDXMLDocument.init(xmlString: xmlString!, options: 0)
            
            //开始解析
            do{
                
                let children:[DDXMLNode]? = try doc.nodes(forXPath: "//Student") as [DDXMLNode]?
                
                //遍历每个元素
                for obj:DDXMLNode in children! {
                    
                    let element:DDXMLElement = obj as! DDXMLElement
                    
                    let name:String? = element.attribute(forName: "name")?.stringValue
                    let age:String? = element.attribute(forName: "age")?.stringValue
                    
                    print("name = \(name!)\n age = \(age!)\n====")
                    
                }
                
            }catch{
                
                print("解析失败")
                
            }
            
        }catch{
            
            print("解析刚开始就挂了")
        }

    }

    @IBAction func xxmmllReader(_ sender: Any) {
        
        do{
            let xmlString:String? = try String(contentsOfFile: xmlPath!)
            
            let dict = try XMLReader.dictionary(forXMLString: xmlString!) as NSDictionary
            
            stu = Stu.deserialize(from: dict["Class"]! as? NSDictionary)
            
            guard stu?.Student != nil else{
                return
            }
            
            for s in (stu?.Student)! {
                
                print("name = \(s.name!)\nage=\(s.age!)\n=====")
            }
            
        }catch{
            print("挂了")
        }
    }

    

}

