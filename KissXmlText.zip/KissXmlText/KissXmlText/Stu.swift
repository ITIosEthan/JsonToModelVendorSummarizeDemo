//
//  Stu.swift
//  KissXmlText
//
//  Created by macOfEthan on 17/8/18.
//  Copyright © 2017年 macOfEthan. All rights reserved.
//

import UIKit

struct Stu: HandyJSON {
    
    var Student:[SSS]?
    
}

struct SSS:HandyJSON {
    
    var name:String?
    var age:String?
}


