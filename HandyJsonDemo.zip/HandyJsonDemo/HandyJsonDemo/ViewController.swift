//
//  ViewController.swift
//  HandyJsonDemo
//
//  Created by macOfEthan on 17/8/16.
//  Copyright © 2017年 macOfEthan. All rights reserved.
//

import UIKit
import HandyJSON
import Alamofire

let textUrl:String = "http://news-at.zhihu.com/api/4/news/latest"

var model:TextModel?

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        Alamofire.request(textUrl, method: .get, parameters: nil).responseString { (dataResponse) in
                        
            guard dataResponse.result.isSuccess == true else{
                
                return
            }
            
            guard let jsonString:String = dataResponse.result.value else{
            
                return
            }
            
            model = TextModel.deserialize(from: jsonString)
            
            for m in model!.stories! {
                
                print("images = \(m.images![0])\n type = \(m.type!)\n myId = \(m.myId!)\n ga_prefix = \(m.ga_prefix!)\n title = \(m.title!)")
            }
            
            for m in model!.top_stories! {
                print("image = \(m.image!)\n type = \(m.type!)\n myId = \(m.myId!)\n ga_prefix = \(m.ga_prefix!)\n title = \(m.title!)")
            }
        }

    }




}

