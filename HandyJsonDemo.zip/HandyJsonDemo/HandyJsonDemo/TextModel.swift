//
//  TextModel.swift
//  HandyJsonDemo
//
//  Created by macOfEthan on 17/8/16.
//  Copyright © 2017年 macOfEthan. All rights reserved.
//

import UIKit
import HandyJSON

struct TextModel: HandyJSON {
    
    var date:String?
    var stories:[storiesModel]?
    var top_stories:[top_storiesModel]?
}

struct storiesModel:HandyJSON {
    
    var images:[String]?
    var type:Int64?
    var myId:Int64?
    var ga_prefix:String?
    var title:String?
    
    //自定义解析规则 指定解析规则可以防止后边强制拆包
    mutating func mapping(mapper: HelpingMapper) {
        
        mapper <<<
        self.myId <-- "id"
        
    }
}

struct top_storiesModel:HandyJSON {
    
    var image:String?
    var type:Int64?
    var myId:Int64?
    var ga_prefix:String?
    var title:String?
    
    mutating func mapping(mapper: HelpingMapper) {
        
        mapper <<<
            self.myId <-- "id"
    }
}
